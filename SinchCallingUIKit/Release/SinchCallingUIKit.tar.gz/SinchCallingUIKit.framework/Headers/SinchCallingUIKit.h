//
//  SinchCallingUIKit.h
//  SinchCallingUIKit
//
//  Created by christian jensen on 2/24/15.
//  Copyright (c) 2015 christian jensen. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SinchCallingUIKit.
FOUNDATION_EXPORT double SinchCallingUIKitVersionNumber;

//! Project version string for SinchCallingUIKit.
FOUNDATION_EXPORT const unsigned char SinchCallingUIKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SinchCallingUIKit/PublicHeader.h>


#import <SinchCallingUIKit/CallingManager.h>



